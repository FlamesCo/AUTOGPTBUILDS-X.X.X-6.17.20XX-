import abc


class Memory(abc.ABC):
    pass


class MemoryItem(abc.ABC):
    pass


class MessageHistory(abc.ABC):
    pass
